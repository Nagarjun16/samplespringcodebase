package com.ngen.cosys.aed.validators;

import org.springframework.stereotype.Service;

@Service
public interface AedvalidationGroup {

}

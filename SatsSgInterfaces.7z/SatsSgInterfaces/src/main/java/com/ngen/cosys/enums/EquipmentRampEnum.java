package com.ngen.cosys.enums;

public enum EquipmentRampEnum {
   RAMP, EQUIPMENT;

}

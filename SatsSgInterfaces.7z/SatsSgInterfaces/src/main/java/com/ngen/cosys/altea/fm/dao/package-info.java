/**
 * 
 */
package com.ngen.cosys.altea.fm.dao;
/**
 * 
 */
package com.ngen.cosys.altea.fm.util;
package com.ngen.cosys;

import org.springframework.context.annotation.Configuration;

@Configuration
//@ImportResource("classpath:/config/camsInterfaceConfig.xml")
public class WebServiceTemplateConfiguration {

}

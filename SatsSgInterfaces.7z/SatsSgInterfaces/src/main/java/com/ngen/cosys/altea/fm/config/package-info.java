/**
 * 
 */
package com.ngen.cosys.altea.fm.config;
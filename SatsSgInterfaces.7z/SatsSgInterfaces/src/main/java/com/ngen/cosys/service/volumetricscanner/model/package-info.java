/**
 * 
 */
package com.ngen.cosys.service.volumetricscanner.model;
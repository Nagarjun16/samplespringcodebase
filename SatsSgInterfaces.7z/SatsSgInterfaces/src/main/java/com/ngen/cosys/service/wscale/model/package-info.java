/**
 * 
 */
package com.ngen.cosys.service.wscale.model;
package com.ngen.cosys.enums;

public enum InOutEnum {
   IN, OU;

}

package snippet;

public class Snippet {
	public static void main(String[] args) {
		com.ngen.cosys.tracing.surveydetails
	}
}


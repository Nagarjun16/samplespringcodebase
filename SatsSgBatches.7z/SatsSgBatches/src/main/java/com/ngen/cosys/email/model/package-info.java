/**
 * 
 */
package com.ngen.cosys.email.model;
package com.ngen.cosys.application.dao;

import com.ngen.cosys.framework.exception.CustomException;

public interface UpdateInProcessForAwbNumberStockDao {

	void UpdateInProcessForAwbNumberStock() throws CustomException;
}

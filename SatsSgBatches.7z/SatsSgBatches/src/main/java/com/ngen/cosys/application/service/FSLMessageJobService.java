package com.ngen.cosys.application.service;

import com.ngen.cosys.framework.exception.CustomException;

public interface FSLMessageJobService {

	void getFSLMessageDefinition() throws CustomException;
}

package com.ngen.cosys.application.job;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.ngen.cosys.scheduler.job.AbstractCronJob;

public class FlightCompletionJob extends AbstractCronJob {
   @Override
   protected void executeInternal(JobExecutionContext jobExecutionContext) throws JobExecutionException {
      super.executeInternal(jobExecutionContext);

 try {
 }catch(Exception e) {
    
 }
 


 }
}

package com.ngen.cosys.application.service;

import com.ngen.cosys.framework.exception.CustomException;

public interface UpdateInProcessForAwbNumberStockService {

	void UpdateInProcessForAwbNumberStock() throws CustomException;

}

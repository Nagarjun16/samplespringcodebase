package com.ngen.cosys.application.job;

import com.ngen.cosys.scheduler.job.AbstractCronJob;

public class PreannouncementUldMessagesJob extends AbstractCronJob {

}

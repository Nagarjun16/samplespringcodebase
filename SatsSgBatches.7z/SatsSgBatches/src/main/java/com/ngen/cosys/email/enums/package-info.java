/**
 * 
 */
package com.ngen.cosys.email.enums;
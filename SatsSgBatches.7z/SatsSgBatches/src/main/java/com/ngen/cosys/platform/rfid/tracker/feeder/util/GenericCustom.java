package com.ngen.cosys.platform.rfid.tracker.feeder.util;

public class GenericCustom extends RuntimeException {

	public GenericCustom() {
		super();
	}
}

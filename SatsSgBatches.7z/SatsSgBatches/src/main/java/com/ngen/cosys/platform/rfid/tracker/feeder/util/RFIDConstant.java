package com.ngen.cosys.platform.rfid.tracker.feeder.util;

public class RFIDConstant {

	public static final String RECEIVED = "";

	public static final String STORAGE = "";
	public static final String BUILD_UP = "";
	public static final String HANDOVER = "";

	public static final String BAY_DROPOFF = "";
	public static final String FLIGHT_LOAD = "";
	public static final String FLIGHT_OFFLOAD = "";

	public static final String UNLOAD = "";
	public static final String BAY_PICK_UP = "";

}

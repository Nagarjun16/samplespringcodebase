/**
 * 
 */
package com.ngen.cosys.email.config;
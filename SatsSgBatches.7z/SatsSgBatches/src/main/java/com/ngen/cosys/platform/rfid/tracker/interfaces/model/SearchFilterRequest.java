package com.ngen.cosys.platform.rfid.tracker.interfaces.model;

import lombok.Data;

@Data
public class SearchFilterRequest {
   
	private String station;
}

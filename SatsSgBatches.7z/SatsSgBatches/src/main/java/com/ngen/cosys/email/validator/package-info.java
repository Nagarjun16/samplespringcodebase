/**
 * 
 */
package com.ngen.cosys.email.validator;
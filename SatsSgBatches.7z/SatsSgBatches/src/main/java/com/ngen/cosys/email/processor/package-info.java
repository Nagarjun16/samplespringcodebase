/**
 * 
 */
package com.ngen.cosys.email.processor;
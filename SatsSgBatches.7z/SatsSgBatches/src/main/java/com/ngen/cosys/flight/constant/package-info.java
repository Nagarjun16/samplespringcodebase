/**
* Constant Objects
* <p>
* This package contains the Constants and ENUM
* </p>
*
* @since 1.0
* @author NIIT Technologies Ltd
* @version 1.0
*/
package com.ngen.cosys.flight.constant;
/**
 * 
 */
package com.ngen.cosys.email.logger;
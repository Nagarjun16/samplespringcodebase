/**
 * SchFlightSegTempBO.java
 * 
 * Copyright <PRE><IMG SRC = XX></IMG></PRE>
 *
 * Version      Date         Author      Reason
 * 1.0          28 July, 2017   NIIT      -
 */
package com.ngen.cosys.flight.model;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ngen.cosys.framework.model.BaseBO;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * This is model class for SchFlightSegTempBO.
 * 
 * @author NIIT Technologies Ltd
 * @version 1.0
 */
@ApiModel
@ToString
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Component
@Scope("prototype")
public class SchFlightSegTempBO extends BaseBO {
   /**
    * The default serialVersionUID.
    */
   private static final long serialVersionUID = 1L;
   private long flightScheduleID;
   private String fltCar;
   private String fltNum;
   private String aptBrd;
   private short brdLeg;
   private String aptOff;
   private short offLeg;
   private Integer frequncy;
   private String serviceType;
}
package com.ngen.cosys.shipment.service;

import static org.junit.Assert.*;

import org.junit.Test;

public class ShipmentOnHoldImplTest {
	
	@Test
    public void testFetchInvalidOperating() {	
       assertTrue(true);
    }
}

package com.ngen.cosys.shipment.nawb.validator;

public interface NeutralAWBValidatorGroup {

}

/**
* Stock Management base package
* <p>
* This package contains the Stock Management codes
* </p>
*
* @since 1.0
* @author NIIT Technologies Ltd
* @version 1.0
*/
package com.ngen.cosys.shipment.stockmanagement;
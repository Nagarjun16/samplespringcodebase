package com.ngen.cosys.shipment.awb.validator;

public interface AWBDocumentConstraintsValidator {

}

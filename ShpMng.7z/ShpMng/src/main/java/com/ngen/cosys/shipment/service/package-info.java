/**
* Service Objects
* <p>
* This package contains the Services
* </p>
*
* @since 1.0
* @author NIIT Technologies Ltd
* @version 1.0
*/
package com.ngen.cosys.shipment.service;
/*
 * Validation group for house
 */
package com.ngen.cosys.shipment.house.validator;

public interface HouseWayBillValidationGroup {

}
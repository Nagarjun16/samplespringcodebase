package com.ngen.cosys.shipment.terminaltoterminalhandover.queryconfig;

import com.ngen.cosys.multitenancy.utilities.MultiTenantUtility;

public class QueryConfig {

	public static final String Get_ShpDetailsAtTerminal = "getShpDetailsAtTerminal";
	public static final String Insert_TransferShipmentToTerminal = "transferShipmentToTerminal";
	public static final String GET_DETAILSOFSHIPMENTTOTERMINAL = "getDetailsOfShipmentToTerminal";
	public static final String GET_SHPDETAILSATTERMINAL = "getShpDetailsAtTerminal";
	public static final String INSERT_TRANSFERSHIPMENTTOTERMINAL = "transferShipmentToTerminal";

	public static final String UPDATE_SHIPMENT_LOCATION = "updateShipmentLocation";
	public static final String UPDATE_ULD_LOCATION = "updateULDLocation";
	
	public static final String CREATED_USERCODE = "";
	public static final String LAST_MODIFIEDUSER = "";

}

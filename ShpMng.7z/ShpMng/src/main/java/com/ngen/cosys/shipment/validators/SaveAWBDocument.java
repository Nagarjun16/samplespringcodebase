package com.ngen.cosys.shipment.validators;

public interface SaveAWBDocument {

}

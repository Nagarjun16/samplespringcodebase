/**
 * 
 */
/**
 * @author Varadaraj.Muni
 *
 */
package com.ngen.cosys.shipment.house.model;
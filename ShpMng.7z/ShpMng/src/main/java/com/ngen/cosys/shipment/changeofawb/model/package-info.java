/**
 *   
 *   This package contains models 
 *   related to change of awb
 *   
 */
package com.ngen.cosys.shipment.changeofawb.model;


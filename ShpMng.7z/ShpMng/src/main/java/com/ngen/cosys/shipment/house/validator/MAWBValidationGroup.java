package com.ngen.cosys.shipment.house.validator;

public interface MAWBValidationGroup {

}

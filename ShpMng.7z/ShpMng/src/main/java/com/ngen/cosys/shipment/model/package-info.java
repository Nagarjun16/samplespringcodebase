/**
* Model Objects
* <p>
* This package contains the Models
* </p>
*
* @since 1.0
* @author NIIT Technologies Ltd
* @version 1.0
*/
package com.ngen.cosys.shipment.model;
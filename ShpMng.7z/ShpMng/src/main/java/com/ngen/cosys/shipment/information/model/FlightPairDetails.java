package com.ngen.cosys.shipment.information.model;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class FlightPairDetails {
	private List<BookingFlightDetails> flightDetails;
}

/**
 * 
 */
/**
 * @author Ashu.Gupta
 *
 */
package com.ngen.cosys.shipment.information.model;
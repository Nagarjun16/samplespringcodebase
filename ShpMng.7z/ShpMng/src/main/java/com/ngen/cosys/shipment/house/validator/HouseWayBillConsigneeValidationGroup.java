/**
 * Will be used to validate consignee details based on tenan airport 
 */
package com.ngen.cosys.shipment.house.validator;

public interface HouseWayBillConsigneeValidationGroup {

}

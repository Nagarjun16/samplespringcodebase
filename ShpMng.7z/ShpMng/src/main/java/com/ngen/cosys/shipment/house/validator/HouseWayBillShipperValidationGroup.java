/**
 * Will be used to validate shipper  details based on tenant airport 
 */
package com.ngen.cosys.shipment.house.validator;

/**
 * @author Yuganshu.Khanna
 *
 */
public interface HouseWayBillShipperValidationGroup {

}

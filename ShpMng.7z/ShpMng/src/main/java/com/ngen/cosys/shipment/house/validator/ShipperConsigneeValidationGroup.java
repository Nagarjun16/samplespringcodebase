/**
 * 
 */
package com.ngen.cosys.shipment.house.validator;

/**
 * @author Akbar.Ansari
 *
 */
public interface ShipperConsigneeValidationGroup {

}

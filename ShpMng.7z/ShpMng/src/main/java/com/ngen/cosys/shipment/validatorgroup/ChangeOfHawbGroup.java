/**
 *   ChangeOfHawbGroup.java
 *   
 *   Copyright <PRE><IMG SRC = XX></IMG></PRE>
 *
 * Version      Date         Author      Reason
 * 1.0          30 May, 2018   NIIT      -
 */
package com.ngen.cosys.shipment.validatorgroup;

/**
 * This interface will be used as a validator group
 * for hawb change
 * @author Yuganshu.K
 *
 */
public interface ChangeOfHawbGroup {

}

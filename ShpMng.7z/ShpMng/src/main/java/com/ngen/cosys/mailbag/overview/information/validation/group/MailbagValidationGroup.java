package com.ngen.cosys.mailbag.overview.information.validation.group;

public interface MailbagValidationGroup {

}

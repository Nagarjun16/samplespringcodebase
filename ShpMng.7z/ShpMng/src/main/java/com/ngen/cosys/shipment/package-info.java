/**
* Servlet Object
* <p>
* This package contains the Configuration Servlet
* </p>
*
* @since 1.0
* @author NIIT Technologies Ltd
* @version 1.0
*/
package com.ngen.cosys.shipment;
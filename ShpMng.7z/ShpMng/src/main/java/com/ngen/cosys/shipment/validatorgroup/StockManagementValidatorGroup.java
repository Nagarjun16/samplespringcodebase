package com.ngen.cosys.shipment.validatorgroup;

public interface StockManagementValidatorGroup {

}

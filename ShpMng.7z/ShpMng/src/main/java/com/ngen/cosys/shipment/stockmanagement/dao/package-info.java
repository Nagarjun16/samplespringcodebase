/**
* DAO Objects
* <p>
* This package contains the DAO Objects
* </p>
*
* @since 1.0
* @author NIIT Technologies Ltd
* @version 1.0
*/
package com.ngen.cosys.shipment.stockmanagement.dao;
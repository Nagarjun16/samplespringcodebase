/**
 * 
 */
package com.ngen.cosys.report.logger.model;
/**
 * 
 */
package com.ngen.cosys.esb.connector.util;
/**
 * Message Constant
 */
package com.ngen.cosys.message.common;

/**
 * Message Constant
 */
public final class MessageConstant {
}

/**
 * 
 */
package com.ngen.cosys.esb.connector.payload;
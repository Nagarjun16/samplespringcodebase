/**
 * 
 */
package com.ngen.cosys.report.logger.enums;
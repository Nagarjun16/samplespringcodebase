/**
 * 
 */
package com.ngen.cosys.report.logger.dao;
package com.ngen.cosys.util;

public class SubmitDataToCustomsUtils {

}
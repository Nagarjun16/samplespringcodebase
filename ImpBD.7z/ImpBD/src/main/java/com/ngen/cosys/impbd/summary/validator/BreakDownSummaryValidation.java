package com.ngen.cosys.impbd.summary.validator;

public interface BreakDownSummaryValidation {

}
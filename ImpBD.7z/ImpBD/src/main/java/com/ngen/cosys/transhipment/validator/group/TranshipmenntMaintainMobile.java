package com.ngen.cosys.transhipment.validator.group;

public interface TranshipmenntMaintainMobile {

}

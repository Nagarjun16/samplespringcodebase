/**
 * 
 */
/**
 * @author Varadaraj.Muni
 *
 */
package com.ngen.cosys.impbd.mail.manifest.service;
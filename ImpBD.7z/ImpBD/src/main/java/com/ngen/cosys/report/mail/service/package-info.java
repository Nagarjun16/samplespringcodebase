/**
 * 
 */
package com.ngen.cosys.report.mail.service;
package com.ngen.cosys.impbd.shipment.breakdown.validator;

public interface InboundBreakDownValidationGroup {

}

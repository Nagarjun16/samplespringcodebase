package com.ngen.cosys.validators;

public interface HandoverValidationGroup {

}

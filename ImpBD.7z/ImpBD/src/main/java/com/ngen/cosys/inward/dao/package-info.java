/**
 * 
 */
/**
 * @author Varadaraj.Muni
 *
 */
package com.ngen.cosys.inward.dao;
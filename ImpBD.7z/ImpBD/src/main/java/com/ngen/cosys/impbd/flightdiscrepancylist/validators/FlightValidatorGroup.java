package com.ngen.cosys.impbd.flightdiscrepancylist.validators;

public interface FlightValidatorGroup {
      
}

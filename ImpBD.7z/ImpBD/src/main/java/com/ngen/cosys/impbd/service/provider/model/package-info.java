/**
 * 
 */
/**
 * @author Bijay.Kumar
 *
 */
package com.ngen.cosys.impbd.service.provider.model;
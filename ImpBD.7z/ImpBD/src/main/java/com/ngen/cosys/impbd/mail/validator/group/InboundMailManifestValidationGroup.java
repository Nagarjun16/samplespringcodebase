package com.ngen.cosys.impbd.mail.validator.group;

public interface InboundMailManifestValidationGroup {

}
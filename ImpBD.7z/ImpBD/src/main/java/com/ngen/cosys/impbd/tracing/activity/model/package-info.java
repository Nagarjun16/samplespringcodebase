/**
 * 
 */
/**
 * @author Varadaraj.Muni
 *
 */
package com.ngen.cosys.impbd.tracing.activity.model;
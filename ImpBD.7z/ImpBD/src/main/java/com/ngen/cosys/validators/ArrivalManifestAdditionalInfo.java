package com.ngen.cosys.validators;

public interface ArrivalManifestAdditionalInfo {

}

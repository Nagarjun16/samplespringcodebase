package com.ngen.cosys.impbd.shipment.verification.validator;

public interface DgDetailsSave {

}

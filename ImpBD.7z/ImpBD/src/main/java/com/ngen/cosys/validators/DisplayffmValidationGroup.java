package com.ngen.cosys.validators;

public interface DisplayffmValidationGroup {

}
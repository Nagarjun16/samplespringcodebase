/**
 * 
 */
package com.ngen.cosys.impbd.service.mail.validator;